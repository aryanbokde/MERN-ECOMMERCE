import React from 'react';
import './Payment.css';
import  PaymentForm  from './PaymentSubComponent';

import MetaData from '../View/MetaData';
import CheckoutSteps from './CheckoutSteps';


const Payment = () => {
  


  return (
    <div className='bg-p'>
      <MetaData title='Payment'/>
      <CheckoutSteps activeStep={2}/>
        <PaymentForm/>       
    </div>
  );
};

export default Payment;
